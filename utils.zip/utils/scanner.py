import nmap
import socket
import platform
import os
import json
import subprocess
from datetime import datetime

class NetworkScanner:
    def __init__(self):
        self.nm = nmap.PortScanner()
    
    def basic_scan(self, target):
        """Basic port scan with OS detection"""
        try:
            # Run Nmap scan with OS detection
            self.nm.scan(hosts=target, arguments='-O -sV')
            
            results = {
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'target': target,
                'scan_type': 'basic',
                'hosts': {}
            }
            
            for host in self.nm.all_hosts():
                results['hosts'][host] = {
                    'status': self.nm[host].state(),
                    'os_detection': self.get_os_info(host),
                    'ports': self.get_port_info(host)
                }
            
            return results
        except Exception as e:
            return {'error': str(e)}
    
    def comprehensive_scan(self, target):
        """Comprehensive scan with vulnerability detection"""
        try:
            # More thorough scan with scripts
            self.nm.scan(hosts=target, arguments='-sS -sV -O --script vuln')
            
            results = {
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'target': target,
                'scan_type': 'comprehensive',
                'hosts': {}
            }
            
            for host in self.nm.all_hosts():
                results['hosts'][host] = {
                    'status': self.nm[host].state(),
                    'os_detection': self.get_os_info(host),
                    'ports': self.get_port_info(host),
                    'vulnerabilities': self.get_vulnerability_info(host)
                }
            
            return results
        except Exception as e:
            return {'error': str(e)}
    
    def quick_scan(self, target):
        """Quick scan for common ports"""
        try:
            self.nm.scan(hosts=target, arguments='-F')
            
            results = {
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'target': target,
                'scan_type': 'quick',
                'hosts': {}
            }
            
            for host in self.nm.all_hosts():
                results['hosts'][host] = {
                    'status': self.nm[host].state(),
                    'ports': self.get_port_info(host)
                }
            
            return results
        except Exception as e:
            return {'error': str(e)}
    
    def get_os_info(self, host):
        """Extract OS information for a host"""
        os_info = []
        if 'osmatch' in self.nm[host]:
            for os_match in self.nm[host]['osmatch']:
                os_info.append({
                    'name': os_match.get('name', 'Unknown'),
                    'accuracy': os_match.get('accuracy', '0')
                })
        return os_info
    
    def get_port_info(self, host):
        """Extract port information for a host"""
        port_info = {}
        if 'tcp' in self.nm[host]:
            for port in self.nm[host]['tcp']:
                port_info[port] = {
                    'state': self.nm[host]['tcp'][port].get('state', 'unknown'),
                    'service': self.nm[host]['tcp'][port].get('name', 'unknown'),
                    'product': self.nm[host]['tcp'][port].get('product', 'unknown'),
                    'version': self.nm[host]['tcp'][port].get('version', 'unknown')
                }
        return port_info
    
    def get_vulnerability_info(self, host):
        """Extract vulnerability information for a host"""
        vuln_info = []
        
        if 'tcp' in self.nm[host]:
            for port in self.nm[host]['tcp']:
                if 'script' in self.nm[host]['tcp'][port]:
                    for script_name, script_output in self.nm[host]['tcp'][port]['script'].items():
                        if 'vuln' in script_name:
                            vuln_info.append({
                                'port': port,
                                'name': script_name,
                                'details': script_output
                            })
        
        return vuln_info
    
    def get_local_host_info(self):
        """Get information about the local system"""
        info = {
            'hostname': socket.gethostname(),
            'ip': socket.gethostbyname(socket.gethostname()),
            'os': platform.system(),
            'os_version': platform.version(),
            'architecture': platform.architecture()[0]
        }
        return info
